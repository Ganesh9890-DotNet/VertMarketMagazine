﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VertMagazine_APISettings.ServiceEndPoints
{
    public class APIUrl
    {
        static APIUrl()
        {
            BaseURL = ConfigurationManager.AppSettings["BaseURL"];
            GetToken = BaseURL + ConfigurationManager.AppSettings["GenerateToken"];
            GetCategories = BaseURL + ConfigurationManager.AppSettings["GetCategories"];
            GetMagazineBasedOnCategory = BaseURL + ConfigurationManager.AppSettings["GetMagazines"];
            GetSubcribers = BaseURL + ConfigurationManager.AppSettings["GetSubscribers"];
            PostAnswers = BaseURL + ConfigurationManager.AppSettings["PostAnswer"];
        }
        public static string BaseURL { get; set; }
        public static string GetToken { get; set; }
        public static string GetCategories { get; set; }
        public static string GetMagazineBasedOnCategory { get; set; }
        public static string GetSubcribers { get; set; }
        public static string PostAnswers { get; set; }

    }
}
