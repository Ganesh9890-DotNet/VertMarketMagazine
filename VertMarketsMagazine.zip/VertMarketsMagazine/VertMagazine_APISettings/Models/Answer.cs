﻿using System.Collections.Generic;

namespace VertMarketsMagazine_APISettings
{
    public class Answer : Token
    {
        public AnswerDetail data { get; set; }
        public string message { get; set; }
    }
    public class AnswerDetail
    {
        public string totalTime { get; set; }
        public bool answerCorrect { get; set; }
        public List<string> shouldBe { get; set; }
    }

    public class AnswerRequest
    {
        public List<string> subscribers { get; set; }
    }
}
