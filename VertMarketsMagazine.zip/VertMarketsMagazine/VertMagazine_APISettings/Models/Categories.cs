﻿using System.Collections.Generic;

namespace VertMarketsMagazine_APISettings
{
    public class Categories : Token
    {
        public List<string> data { get; set; }
    }
}
