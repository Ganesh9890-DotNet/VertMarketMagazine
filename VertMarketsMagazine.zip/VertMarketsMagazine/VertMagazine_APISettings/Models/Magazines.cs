﻿using System.Collections.Generic;

namespace VertMarketsMagazine_APISettings
{

    public class Magazines : Token
    {
        public List<CategoryDetail> data { get; set; } = new List<CategoryDetail>();
    }

    public class CategoryDetail
    {
        public int id { get; set; }
        public string name { get; set; }
        public string category { get; set; }
    }


}
