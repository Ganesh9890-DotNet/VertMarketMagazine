﻿namespace VertMarketsMagazine_APISettings
{
    public class Token
    {
        public bool success { get; set; } = false;
        public string token { get; set; } = string.Empty;
    }
}
