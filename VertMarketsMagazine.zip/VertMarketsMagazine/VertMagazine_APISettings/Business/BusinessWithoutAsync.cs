﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Formatting;
using System.Text;
using System.Threading.Tasks;
using VertMagazine_APISettings.ServiceEndPoints;
using VertMarketsMagazine_APISettings;

namespace VertMagazine_APISettings.Business
{
    public class BusinessWithoutAsync
    {
        public string APIToken { get; set; } = string.Empty;
        public BusinessWithoutAsync(string Token)
        {
            APIToken = Token;
        }

        
        public Categories GetCategories()
        {
            WebClient client = new WebClient();
            string URI = String.Format(APIUrl.GetCategories, APIToken);
            var json = client.DownloadString(URI);
            Categories categories = JsonConvert.DeserializeObject<Categories>(json);
            return categories;
        }
        public Subscribers GetSubscribers()
        {
            WebClient client = new WebClient();
            string URI = String.Format(APIUrl.GetSubcribers, APIToken);
            var json = client.DownloadString(URI);
            Subscribers subscribers = JsonConvert.DeserializeObject<Subscribers>(json);
            return subscribers;
        }

        public Magazines GetSpecificCategory(string Category)
        {
            WebClient client = new WebClient();
            string URI = string.Format(APIUrl.GetMagazineBasedOnCategory, APIToken, Category);
            var json = client.DownloadString(URI);
            Magazines respMagazine = JsonConvert.DeserializeObject<Magazines>(json,
                new JsonSerializerSettings
                {
                    PreserveReferencesHandling = PreserveReferencesHandling.Objects
                });


            return respMagazine;
        }

        public Answer PostAnswer(AnswerRequest inputdata)
        {
            WebClient client = new WebClient();
            string URI = string.Format(APIUrl.PostAnswers, APIToken);
            client.Headers[HttpRequestHeader.ContentType] = "application/json";
            string data = JsonConvert.SerializeObject(inputdata);
            var json = client.UploadString(URI, data);
            Answer specificCategory = JsonConvert.DeserializeObject<Answer>(json);
            return specificCategory;
        }
    }
}
