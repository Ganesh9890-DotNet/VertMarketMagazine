﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Formatting;
using System.Text;
using System.Threading.Tasks;
using VertMagazine_APISettings.ServiceEndPoints;
using VertMarketsMagazine_APISettings;

namespace VertMagazine_APISettings.Business
{
    public class BusinessLogic
    {
        public string APIToken { get; set; } = string.Empty;
        public BusinessLogic(string Token)
        {
            APIToken = Token;
        }
         
        public async Task<Categories> GetCategoriesAsync()
        {

            HttpClient httpClient = new HttpClient();
            Categories categories = new Categories();
            HttpResponseMessage Response;
            string URI = String.Format(APIUrl.GetCategories, APIToken);

            if (string.IsNullOrEmpty(APIToken))
            {
                APIToken = GetToken.RefreshToken();
            }

            Response = await httpClient.GetAsync(URI);
            if (Response.IsSuccessStatusCode)
            {
                categories = await Response.Content.ReadAsAsync<Categories>(new[] { new JsonMediaTypeFormatter() });
            }
            return categories;
        }
        public async Task<Subscribers> GetSubscribersAsync()
        {
            HttpClient httpClient = new HttpClient();
            Subscribers subscribers = new Subscribers();
            HttpResponseMessage Response;
            string URI = String.Format(APIUrl.GetSubcribers, APIToken);

            if (string.IsNullOrEmpty(APIToken))
            {
                APIToken = GetToken.RefreshToken();
            }
            
            Response = await httpClient.GetAsync(URI);
            if (Response.IsSuccessStatusCode)
            {
                subscribers = await Response.Content.ReadAsAsync<Subscribers>(new[] { new JsonMediaTypeFormatter() });
            }

            return subscribers;
        }

        public async Task<Magazines> GetSpecificCategoryAsyn(string Category)
        {
            Magazines respMagazine = new Magazines();
            await Task.Run(() =>
            {
                WebClient client = new WebClient();
                string URI = string.Format(APIUrl.GetMagazineBasedOnCategory, APIToken, Category);
                var json = client.DownloadString(URI);
                respMagazine = JsonConvert.DeserializeObject<Magazines>(json,
                    new JsonSerializerSettings
                    {
                        PreserveReferencesHandling = PreserveReferencesHandling.Objects
                    });

            });
            return respMagazine;
        }

        public Answer PostAnswer(AnswerRequest inputdata)
        {
            WebClient client = new WebClient();
            string URI = string.Format(APIUrl.PostAnswers, APIToken);
            client.Headers[HttpRequestHeader.ContentType] = "application/json";
            string data = JsonConvert.SerializeObject(inputdata);
            var json = client.UploadString(URI, data);
            Answer specificCategory = JsonConvert.DeserializeObject<Answer>(json);
            return specificCategory;
        }
    }
}
