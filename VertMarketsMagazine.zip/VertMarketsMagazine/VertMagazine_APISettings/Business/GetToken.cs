﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using VertMagazine_APISettings.ServiceEndPoints;
using VertMarketsMagazine_APISettings;

namespace VertMagazine_APISettings.Business
{
    public class GetToken
    {
        public static string RefreshToken()
        {
            Token token = GenerateToken();
            return token.token;
        }
        private static Token GenerateToken()
        {
            WebClient client = new WebClient();
            var json = client.DownloadString(APIUrl.GetToken);
            Token token = JsonConvert.DeserializeObject<Token>(json);
            return token;
        }
    }
}
