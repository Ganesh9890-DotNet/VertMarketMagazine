﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VertMagazine_APISettings.Business;
using VertMarketsMagazine_APISettings;

namespace VertMarketsMagazine
{
    public class Program
    {


        static void Main(string[] args)
        {

            Console.WriteLine("Application Started ==> " + DateTime.Now);

            ProcessRequest();

            //To Improve perfromance of code
            ProcessRequestAsync().GetAwaiter().GetResult();

            Console.ReadKey();
        }

        public static void ProcessRequest()
        {
            Token tokeninput = new Token();
            Categories categories = new Categories();
            Subscribers Subscribers = new Subscribers();
            List<Magazines> Magazinetasks = new List<Magazines>();
            try
            {

                BusinessWithoutAsync mainobj = new BusinessWithoutAsync(GetToken.RefreshToken());

                categories = mainobj.GetCategories();
                Subscribers = mainobj.GetSubscribers();


                foreach (string category in categories.data)
                {
                    Magazinetasks.Add(mainobj.GetSpecificCategory(category));
                }

                List<Magazines> magazines = new List<Magazines>();
                magazines = Magazinetasks.ToList();

                List<string> subsciberIDs = new List<string>();
                foreach (Subscriber x in Subscribers.data)
                {
                    List<int> MagazineId = x.magazineIds;
                    List<string> SubscriberCategories = magazines.SelectMany(z => z.data).Where(y => MagazineId.Contains(y.id)).Select(s => s.category).Distinct().ToList();
                    bool isEqual = Enumerable.SequenceEqual(categories.data.OrderBy(e => e), SubscriberCategories.OrderBy(e => e));
                    if (isEqual)
                        subsciberIDs.Add(x.id);
                }

                Answer answerResponse = null;
                AnswerRequest answerRequest = new AnswerRequest
                {
                    subscribers = subsciberIDs
                };
                answerResponse = mainobj.PostAnswer(answerRequest);
                Console.WriteLine(String.Format("Without Async Operation Result ==> {0}. Is the answer correct ==> {1} , total time ==> {2}", answerResponse.success, answerResponse.data.answerCorrect, answerResponse.data.totalTime));

            }
            catch (Exception ex)
            {
                Console.WriteLine("Something Went Wrong");
            }
        }
        public static async Task ProcessRequestAsync()
        {
            Token tokeninput = new Token();
            Categories categories = new Categories();
            Subscribers Subscribers = new Subscribers();
            List<Task<Magazines>> Magazinetasks = new List<Task<Magazines>>();
            try
            {

                BusinessLogic mainobj = new BusinessLogic(GetToken.RefreshToken());
                //Get Categories and Subscribers using TPL

                var task1 = mainobj.GetCategoriesAsync();
                var task2 = mainobj.GetSubscribersAsync();

                await Task.WhenAll(task1, task2);
                categories = await task1;
                Subscribers = await task2;

                //Generate Tasks for various category 
                foreach (string category in categories.data)
                {
                    Magazinetasks.Add(mainobj.GetSpecificCategoryAsyn(category));
                }

                var magazinetaskCompleted = await Task.WhenAll(Magazinetasks);

                List<Magazines> magazines = new List<Magazines>();
                magazines = magazinetaskCompleted.ToList();

                List<string> subsciberIDs = new List<string>();
                foreach (Subscriber x in Subscribers.data)
                {
                    List<int> MagazineId = x.magazineIds;
                    List<string> SubscriberCategories = magazines.SelectMany(z => z.data).Where(y => MagazineId.Contains(y.id)).Select(s => s.category).Distinct().ToList();
                    bool isEqual = Enumerable.SequenceEqual(categories.data.OrderBy(e => e), SubscriberCategories.OrderBy(e => e));
                    if (isEqual)
                        subsciberIDs.Add(x.id);
                }

                Answer answerResponse = null;
                AnswerRequest answerRequest = new AnswerRequest
                {
                    subscribers = subsciberIDs
                };
                answerResponse = mainobj.PostAnswer(answerRequest);
                Console.WriteLine(String.Format("With ASync Mode Result ==> {0}. Is the answer correct ==> {1} , total time ==> {2}", answerResponse.success, answerResponse.data.answerCorrect, answerResponse.data.totalTime));

            }
            catch (Exception ex)
            {
                Console.WriteLine("Something Went Wrong");
            }
        }

    }
}
